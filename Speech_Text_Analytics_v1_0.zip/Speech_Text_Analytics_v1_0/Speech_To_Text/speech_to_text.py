# -*- coding: utf-8 -*-
"""
Created on Tue Feb 28 22:57:11 2023

@author: Dell
"""

import logging
import time
import azure.cognitiveservices.speech as speechsdk

SPEECH_ENDPOINT = 'https://eastus.api.cognitive.microsoft.com/sts/v1.0/issuetoken'

param1 = 1000
param2 = 10
param3 = 60


###Transforma los nanosegundos devuetos por  duration + offset del metodo recognized
def formato_nanosegundos(nanosegundos):
    segundos = int(nanosegundos / param1 / param1 / param2)
    horas = int(segundos / param3 / param3)
    segundos -= horas*param3*param3
    minutos = int(segundos/param3)
    segundos -= minutos*param3
    return f"{horas:02d}:{minutos:02d}:{segundos:02d}"
        
        
def from_file(audio_fle):
    ###Para determinar que el reconocimiento de voz no ha terminado si es False
    done = False
    ###Variable que guarda la transcripcion del audio
    transcripcion = ""
    duracion = ""
    
    
    ###---------------------------------------------CONFIGURACION PARA CONECTARSE AL SERVICIO DE SPEECH TO TEXT---------------------------------------------
    ### This example requires environment variables named "SPEECH_KEY" and "SPEECH_REGION"
    speech_config = speechsdk.SpeechConfig(subscription='484ca3b25c8e4b079eca3fe7844223b6', region='eastus')
    speech_config.endpoint_id = "SPEECH_ENDPOINT"
    ###Para cambiar el idioma que va a leer en el audio
    speech_config.speech_recognition_language="es-ES"
    ###Para utilizar un audio guardado
    audio_config = speechsdk.audio.AudioConfig(filename=audio_fle)
    speech_recognizer = speechsdk.SpeechRecognizer(speech_config=speech_config, audio_config=audio_config)
     
    
    ###-----------------------------------------------------------------METODOS Y FUNCIONES-----------------------------------------------------------------          
    ###Metodo de stop para la detener la transcripcion
    def stop_cb(evt):
        nonlocal done
        ###Para determinar que el reconocimiento de voz ha terminado
        done = True
    
    ###Metodo para guardar la transcripcion en una variable, además de datos del audio
    def recognized_words(evt):        
        recognized_text = evt.result.text
        recognized_duration = evt.result.duration
        recognized_offset = evt.result.offset        
        nonlocal duracion
        duracion = formato_nanosegundos(recognized_duration + recognized_offset)
        nonlocal transcripcion
        transcripcion += recognized_text+" "
        
        
    ###Connect callbacks to the events fired by the speech recognizer
    ###El metodo recognizing transcribe los eventos que detecta (resultado intermedio)
    #speech_recognizer.recognizing.connect(lambda evt: print('RECOGNIZING: {}'.format(evt)))  
    ###El metodo recognized transcribe los eventos de manera que intenta reconocer de forma correcta (resultado final)
    speech_recognizer.recognized.connect(recognized_words)
    speech_recognizer.session_started.connect(lambda evt: logging.info('SESSION STARTED: {}'.format(evt)))
    speech_recognizer.session_stopped.connect(lambda evt: logging.info('SESSION STOPPED {}'.format(evt)))
    speech_recognizer.canceled.connect(lambda evt: logging.info('CANCELED {}'.format(evt)))
    ###Stop continuous recognition on either session stopped or canceled events
    speech_recognizer.session_stopped.connect(stop_cb)
    speech_recognizer.canceled.connect(stop_cb)

    ###Start continuous speech recognition
    speech_recognizer.start_continuous_recognition()
        
    while not done:
        time.sleep(.5)
    
    speech_recognizer.stop_continuous_recognition()
    
    return transcripcion


def save_transcripts(dir_name_txt,transcription):
    f = open (dir_name_txt,'w')
    f.write(str(transcription))
    f.close()

    