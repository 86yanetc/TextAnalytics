# -*- coding: utf-8 -*-
"""
Created on Wed Mar  1 09:49:00 2023

@author: Dell
"""


##### Censorar informaciones
def censor_dni():
    return "dni"

def censor_tarjeta_credito():
    return "tarjeta de credito"

def censor_importe():
    return "importe"


##### Validaciones
def validacion_dni():
   return "validaciones dni"

def validacion_tarjeta_credito():
    return "tarjeta de credito"

def validacion_importe():
    return "importe"
    
    
