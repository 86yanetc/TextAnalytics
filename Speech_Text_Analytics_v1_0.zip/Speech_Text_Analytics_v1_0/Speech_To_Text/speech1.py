# -*- coding: utf-8 -*-
"""
Created on Mon Mar  6 19:59:04 2023

@author: Dell
"""

from azure.core.credentials import AzureKeyCredential
from azure.ai.textanalytics import TextAnalyticsClient

API_KEY = '484ca3b25c8e4b079eca3fe7844223b6'
ENDPOINT = 'https://eastus.api.cognitive.microsoft.com/sts/v1.0/issuetoken'

def client():
    # Authenticate the client
    client = TextAnalyticsClient(
        endpoint=ENDPOINT, 
        credential=AzureKeyCredential(API_KEY))
    return client