# -*- coding: utf-8 -*-
"""
Created on Tue Feb 28 21:20:36 2023

@author: Yanet Cesaire Velazquez
"""

#!/usr/bin/python
import pandas as pd
import load_metada as lm
import pathlib
import speech_to_text as spt
import text_to_speech as tts
from datetime import date

fecha_actual = date.today()
dir_path_video = str( pathlib.Path(__file__).parent.absolute()) +'\\Datos_Muestras\\Audios\\'
dir_path_transc = str( pathlib.Path(__file__).parent.absolute()) +'\\Datos_Muestras\\Transcripciones\\'
dir_path_text_video = str( pathlib.Path(__file__).parent.absolute()) +'\\Datos_Muestras\\Audios_Transformados\\'

###Leer Metadatos
df = pd.read_csv("Metadata.csv")
new_output = df.index.tolist()

for x in new_output:
    list_metada = lm.load_metada_csv(df,x)
    dir_name = dir_path_video + str(list_metada[0])+'.wav'
        
    dir_name_update = dir_path_text_video + str(list_metada[0]) +'_'+ str(fecha_actual)+'.wav'
    
    transcription = spt.from_file(dir_name)
    dir_name_txt = dir_path_transc + str(list_metada[0])+'.txt'
    
    print("Inicio de las transcripciones")
    spt.save_transcripts(dir_name_txt, transcription)
    print("Salvar las transcripciones a audio")
    tts.save_text_to_speech(transcription, dir_name_update)

print("Fin de las transcripciones")        

    




    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    




 

