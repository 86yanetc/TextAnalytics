# -*- coding: utf-8 -*-
"""
Created on Tue Feb 28 22:28:11 2023

@author: Dell
"""

def load_metada_csv(data,x):
    ###### Load Metada ######
    data_list = []
    nombre_	= data.iloc[x].Nombre
    dni_ =  data.iloc[x].DNI
    tarjeta_de_credito_ = data.iloc[x].Tarjeta_de_credito
    password_ = data.iloc[x].Password
    telefono_ = data.iloc[x].Telefono
    pesos_ = data.iloc[x].Pesos
    
    data_list.append(nombre_)
    data_list.append(dni_)
    data_list.append(tarjeta_de_credito_)
    data_list.append(password_)
    data_list.append(telefono_)
    data_list.append(pesos_)
    
    return data_list

