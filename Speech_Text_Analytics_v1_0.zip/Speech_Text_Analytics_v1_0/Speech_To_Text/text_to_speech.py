# -*- coding: utf-8 -*-
"""
Created on Wed Mar  1 12:00:46 2023

@author: Dell
"""

from gtts import gTTS
language = 'es-us'


def save_text_to_speech(text,file):
      
    speech = gTTS(text=text, lang= language, slow = False)
    
    speech.save(file)
    
    

    