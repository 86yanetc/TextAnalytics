# -*- coding: utf-8 -*-
"""
Created on Tue Mar  7 11:13:38 2023

@author: Dell
"""

import sys
sys.path.append('Text-Analytics')
from credential import client

client = client()

"""
Sentiment analysis & Opinion mining
"""

# https://www.amazon.com/Elgato-Stream-Deck-XL-customizable/dp/B07RL8H55Z/ref=sr_1_3?dchild=1&keywords=stream%2Bdeck&qid=1630914267&sr=8-3&th=1
documents = [
    """
    I have to say that I love this thing. I read a majority of the reviews here on Amazon before I placed my order, and I can say that 95% of the complaints in other reviews are unwarranted.

    Complaints others have had:
    - Short/Fixed USB Cable :: I don't understand this one. Every single wired keyboard and mouse I've ever owned had a fixed cable of the same length. If it doesn't work for you, neither do your mouse and keyboard.
    - LCD "ripples" when you press buttons :: Try not pressing buttons like a 200lb gorilla. Mine doesn't ripple unless I really try to make it do so.
    - There's no built-in functions for MYSOFTWARE :: ... This one annoys me greatly. It's built for streaming software. It literally has STREAM in the name. That said, you can set up custom key binds with custom images for the keys all you want. They work great. I have mine doing a dozen functions that technically aren't supported for OBS, Photoshop, and several other programs.
    - It feels cheap/cheaply made :: What planet these people live on is beyond me... This thing is amazingly well built.
    - There's a long delay when I press buttons! :: Try not streaming on a potato. Mine works beautifully. Any delay is on the users end. (too much BS running in the background/slow computer)
    - It's overpriced! :: If you think this is overpriced, you haven't looked at similar products. Programmable keypads with similar functions (with NO LCD) are just as/more expensive.
    - There's only one LCD, it's not individual displays for each key! :: Who cares? It functions and looks great in the process.

    My Complaints:
    - Fairly minimal native OBS options. This is easily overcome with custom key binds, it would have just been nice to have things like mute mic built-in.
    - Always on display. It really needs to pick up on when the PC display shuts off due to inactivity and do the same. (or shut off when the computer is locked, either way)

    The TLDR: It's great. It works beautifully for streaming, and just as well as a general productivity helper. I don't regret ordering mine and I doubt anybody else will either. 
    """
]


response = client.analyze_sentiment(
    documents=documents,
    language='en-US',
    show_opinion_mining=True
)

positive_reviews = [doc for doc in response if doc.sentiment == "positive"]
mixed_reviews = [doc for doc in response if doc.sentiment == "mixed"]
negative_reviews = [doc for doc in response if doc.sentiment == "negative"]

# Result
# Predicted sentiment for document

for doc in response:
    print('Sentiment Analysis Outcome: {0}'.format(doc.sentiment)) 

    # ocument level sentiment confidence scores between 0 and 1 for each sentiment label.
    print('Overall scores: positive={0:.2f}; neutral={1:.2f}; negative={2:.2f}'.format(
        doc.confidence_scores.positive,
        doc.confidence_scores.neutral,
        doc.confidence_scores.negative
    ))
    print('-'*75)


    # to break down the analysis by each sentence, we can reference the sentences attribute
    sentences = doc.sentences
    for indx, sentence in enumerate(sentences):
        print('Sentence #{0}'.format(indx+1))
        print('Sentence Text: {0}'.format(sentence.text))
        print('Sentence scores: positive={0:.2f}; neutral={1:.2f}; negative={2:.2f}'.format(
        sentence.confidence_scores.positive,
        sentence.confidence_scores.neutral,
        sentence.confidence_scores.negative
        ))
    

        # opinion analysi
        for mined_opinion in sentence.mined_opinions:
            target = mined_opinion.target
            print("......'{}' target '{}'".format(target.sentiment, target.text))
            print("......Target score:\n......Positive={0:.2f}\n......Negative={1:.2f}\n".format(
                target.confidence_scores.positive,
                target.confidence_scores.negative,
            ))
            for assessment in mined_opinion.assessments:
                print("......'{}' assessment '{}'".format(assessment.sentiment, assessment.text))
                print("......Assessment score:\n......Positive={0:.2f}\n......Negative={1:.2f}\n".format(
                    assessment.confidence_scores.positive,
                    assessment.confidence_scores.negative,
                ))
        print()
