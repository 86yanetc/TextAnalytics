# -*- coding: utf-8 -*-
"""
Created on Tue Mar  7 13:22:32 2023

@author: Dell
"""

#####Identify key Phrases

import sys
sys.path.append('Text-Analytics')
from credential import client

post = [
"""
#https://www.reddit.com/r/stocks/comments/q1a8ux/facebook_down_down_down/
#Facebook DOWN DOWN DOWN
#Company Discussion

Hey guys Facebook is getting hit very hard today especially.
There is currently an outage if the app and all there similar sites(Instagram, WhatsApp) which is bad news
Also a whistleblower coming out saying Facebook Is caring more about themselves 
instead of the public’s best interest. 
Isn’t that the mission of every company though, to Benefit their bottom line? 
Doesn’t literally every public for profit company do the exact same thing?
What’s your thoughts on this dip and the long term outlook of Facebook?
I Currently own shares in Facebook""",

"""
# I’m 19 and just opened a Roth IRA. What now?
# https://www.reddit.com/r/personalfinance/comments/q1djl5/im_19_and_just_opened_a_roth_ira_what_now/

Hello! I’m a 19 year old college student, and my current income is about $300 every 2 weeks, 
and my goal is to invest $50 every week into my Roth IRA. I’ve done some research and found 
that the easiest option for me now is the SoFi Roth IRA. Now that I’ve done opened one, what’s 
next? What ETFs and/or mutual funds should I put my money into? Is $50 a week enough? 
How diverse should my portfolio be? I appreciate all of your input, thank you!
"""

client = client()
response = client.extract_key_phrases(documents=posts)

for post in response:
    for key_phrase in post.key_phrases:
	    print(key_phrase)
	print('-'*50)
