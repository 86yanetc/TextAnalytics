# -*- coding: utf-8 -*-
"""
Created on Tue Mar  7 12:26:00 2023

@author: Dell
"""

import sys
sys.path.append('Text-Analytics')
from credential import client

client = client()

# documents = ["I had a wonderful trip to Seattle last week."]
documents = [
    """
    Google is not a conventional company, and we don’t intend to become one. True, we share attributes with the world’s most successful organizations – a focus on innovation and smart business practices comes to mind – but even as we continue to grow, we’re committed to retaining a small-company feel. At Google, we know that every employee has something important to say, and that every employee is integral to our success. We provide individually-tailored compensation packages that can be comprised of competitive salary, bonus, and equity components, along with the opportunity to earn further financial bonuses and rewards.

    Googlers thrive in small, focused teams and high-energy environments, believe in the ability of technology to change the world, and are as passionate about their lives as they are about their work. For more information, visit careers.google.com.
    Mission: Google’s mission is to organize the world’s information and make it universally accessible and useful.
    """
]

response = client.recognize_entities(documents=entities)

for result in response:
    for entity in result.entities:
        print('Entity Name: {0}'.format(entity.text))
        # entity.length # text length
        print('Entity Category: {0}'.format(entity.category))
        print('Entity Subcategory: {0}'.format(entity.subcategory))
        print('Confidence Score: {0}'.format(entity.confidence_score))
        print('-'*50)

def entity_recognition_example(client):

    try:
        documents = ["I had a wonderful trip to Seattle last week."]
        result = client.recognize_entities(documents = documents)[0]

        print("Named Entities:\n")
        for entity in result.entities:
            print("\tText: \t", entity.text, "\tCategory: \t", entity.category, "\tSubCategory: \t", entity.subcategory,
                    "\n\tConfidence Score: \t", round(entity.confidence_score, 2), "\tLength: \t", entity.length, "\tOffset: \t", entity.offset, "\n")

    except Exception as err:
        print("Encountered exception. {}".format(err))
        
entity_recognition_example(text_analytics_client)    