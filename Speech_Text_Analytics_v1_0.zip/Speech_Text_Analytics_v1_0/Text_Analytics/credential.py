# -*- coding: utf-8 -*-
"""
Created on Tue Mar  7 10:57:15 2023

@author: Dell
"""

#Using Azure Text Analytics AI API In Python

from azure.core.credentials import AzureKeyCredential
from azure.ai.textanalytics import TextAnalyticsClient

API_KEY = '74b006a10e90465d9c97adead2034312'
ENDPOINT = 'https://text-analytics-demo111.congnitiveservices.azure.com'

def client():
    # Authenticate the client
    client = TextAnalyticsClient(
        endpoint=ENDPOINT, 
        credential=AzureKeyCredential(API_KEY))
    return client

