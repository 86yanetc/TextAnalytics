# -*- coding: utf-8 -*-
"""
Created on Tue Mar  7 11:59:53 2023

@author: Dell
"""

import sys
sys.path.append('Text-Analytics')
from credential import client

"""
Language detection
"""
text_string = [
    """
Sentiment  analysis  determines  the  polarities  and  strength  of  the  sentiment‐bearing  expressions,  and  it  has  been  an  important  and  attractive  research  area.  In  the  past  decade,  resources  and  tools  have  been  developed  for  sentiment  analysis  in  order  to  provide  subsequent  vital  applications,  such  as  product  reviews,  reputation  management,  call  center  robots,  automatic public  survey,  etc.  However,  most  of  these  resources  are  for  the  English  language.  Being  the  key  to  the  understanding  of  business  and  government  issues,  sentiment  analysis  resources  and  tools  are  required  for  other  major  languages,  e.g.,  Chinese. To  over come  this  obstacle,  we  introduce  CSentiPackage,  where  resources  for  retrieving  sentiment  from  texts  in  the  Chinese  language,  are  provided.  The  related  sentiment  analysis  technologies  and  datasets  are  described  to  give  the  readers  the  opportunities  to  use  resources  and  tools  to  process  Chinese  sentiment  texts  from  the  very  basic  to  the  advanced,  i.e.,  applying  sentiment  dictionaries,  obtaining  sentiment  scores,  and  analyzing  stance  of  social  media  posts  using  the  deep  learning  model.  The  introduced  resources  and  tools  in  this  paper  include  NTUSD,  ANTUSD,  the  Chinese  Morphological  Dataset,  the  Chinese  Opinion  Treebank,  CopeOpi,  and  UTCNN.  These  resources  are  all available  at  http://academiasinicanlplab.github.io/  and  they  are  free  for  the  research  purpose. 
""",
"""
招喚所有的創業家、創新者、改變者、夢想家、實踐者。串連有共同理想及欲改變社會的你。我們藉由創新的點子及科技，影響世界。
Calling on all entrepreneurs, innovators, change makers, dreamers, and doers. connect with like-minded impact fellows in order to bring positive change to society.
We impact The World through creative ideas and innovative technology.
"""
]

client = client()
response = client.detect_language(documents =text_string)
for doc in response:
    print(doc.primary_language.name)
    # response[0].primary_language.iso6391_name
    print(doc.primary_language.confidence_score)

def language_detection_example(client):
    try:
        documents = ["Ce document est rédigé en Français."]
        response = client.detect_language(documents = documents, country_hint = 'us')[0]
        print("Language: ", response.primary_language.name)

    except Exception as err:
        print("Encountered exception. {}".format(err))
        
#language_detection_example(text_analytics_client)