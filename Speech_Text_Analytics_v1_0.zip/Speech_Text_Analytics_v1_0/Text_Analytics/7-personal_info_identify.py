# -*- coding: utf-8 -*-
"""
Created on Tue Mar  7 12:44:19 2023

@author: Dell
"""

import sys
sys.path.append('Text-Analytics')
from credential import client

"""
Personally Identifiable Information (PII) recognition
"""
client = client()

documents = [
    "The employee's SSN is 859-98-0987.",
    "The employee's phone number is 555-555-5555."
]

response = client.recognize_pii_entities(documents, language="en")

for result in response:
    for entity in result.entities:
        print('Text: {0}'.format(entity.text))
        print('Category: {0}'.format(entity.category))
        print('Subcategory: {0}'.format(entity.subcategory))
        print('Confidence Score: {0}'.format(entity.confidence_score))
        print()

