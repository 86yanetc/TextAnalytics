import sys
sys.path.append('Text-Analytics')
from credential import client

client = client()
"""
Opinion mining
"""
documents = [
    """Elgato has stayed very discreet about the fact that their Stream Deck doesn't properly "wake up" (at the same time as your computer) if it's connected through a USB hub.

So your computer wakes up and your Stream Deck stays "offline".

You need to either plug the Stream Deck in your computer's USB port, directly or manually unplug the Stream Deck from your USB hub and plug it in again. Seriously, Elgato?

This situation likely happens 365 times a year. This is completely unacceptable and Elgato needs to push an update to correct this HUGE PROBLEM with their device which works as expected, in all other manners.

I'll change my review if Elgato updates their Stream Deck to work nicely with a USB hub (mine is powered and "active" and still, the Stream Deck "sees" nothing... grrrr). """
]

result = client.analyze_sentiment(documents, show_opinion_mining=True)
result = client.analyze_sentiment(documents, show_opinion_mining=False)
doc_result = [doc for doc in result if not doc.is_error]

positive_reviews = [doc for doc in doc_result if doc.sentiment == "positive"]
mixed_reviews = [doc for doc in doc_result if doc.sentiment == "mixed"]
negative_reviews = [doc for doc in doc_result if doc.sentiment == "negative"]

positive_mined_opinions = []
mixed_mined_opinions = []
negative_mined_opinions = []

for document in doc_result:
    print("Document Sentiment: {}".format(document.sentiment))
    print("Overall scores: positive={0:.2f}; neutral={1:.2f}; negative={2:.2f} \n".format(
        document.confidence_scores.positive,
        document.confidence_scores.neutral,
        document.confidence_scores.negative,
    ))
    for sentence in document.sentences:
        print("Sentence: {}".format(sentence.text))
        print("Sentence sentiment: {}".format(sentence.sentiment))
        print("Sentence score:\nPositive={0:.2f}\nNeutral={1:.2f}\nNegative={2:.2f}\n".format(
            sentence.confidence_scores.positive,
            sentence.confidence_scores.neutral,
            sentence.confidence_scores.negative,
        ))


        # opinion analysi
        for mined_opinion in sentence.mined_opinions:
            target = mined_opinion.target
            print("......'{}' target '{}'".format(target.sentiment, target.text))
            print("......Target score:\n......Positive={0:.2f}\n......Negative={1:.2f}\n".format(
                target.confidence_scores.positive,
                target.confidence_scores.negative,
            ))
            for assessment in mined_opinion.assessments:
                print("......'{}' assessment '{}'".format(assessment.sentiment, assessment.text))
                print("......Assessment score:\n......Positive={0:.2f}\n......Negative={1:.2f}\n".format(
                    assessment.confidence_scores.positive,
                    assessment.confidence_scores.negative,
                ))
        print("\n")
    print("\n")
          

def sentiment_analysis_with_opinion_mining_example(client):
    documents = [
        "The food and service were unacceptable, but the concierge were nice"
    ]

    result = client.analyze_sentiment(documents, show_opinion_mining=True)
    doc_result = [doc for doc in result if not doc.is_error]

    positive_reviews = [doc for doc in doc_result if doc.sentiment == "positive"]
    negative_reviews = [doc for doc in doc_result if doc.sentiment == "negative"]

    positive_mined_opinions = []
    mixed_mined_opinions = []
    negative_mined_opinions = []

    for document in doc_result:
        print("Document Sentiment: {}".format(document.sentiment))
        print("Overall scores: positive={0:.2f}; neutral={1:.2f}; negative={2:.2f} \n".format(
            document.confidence_scores.positive,
            document.confidence_scores.neutral,
            document.confidence_scores.negative,
        ))
        for sentence in document.sentences:
            print("Sentence: {}".format(sentence.text))
            print("Sentence sentiment: {}".format(sentence.sentiment))
            print("Sentence score:\nPositive={0:.2f}\nNeutral={1:.2f}\nNegative={2:.2f}\n".format(
                sentence.confidence_scores.positive,
                sentence.confidence_scores.neutral,
                sentence.confidence_scores.negative,
            ))
            for mined_opinion in sentence.mined_opinions:
                target = mined_opinion.target
                print("......'{}' target '{}'".format(target.sentiment, target.text))
                print("......Target score:\n......Positive={0:.2f}\n......Negative={1:.2f}\n".format(
                    target.confidence_scores.positive,
                    target.confidence_scores.negative,
                ))
                for assessment in mined_opinion.assessments:
                    print("......'{}' assessment '{}'".format(assessment.sentiment, assessment.text))
                    print("......Assessment score:\n......Positive={0:.2f}\n......Negative={1:.2f}\n".format(
                        assessment.confidence_scores.positive,
                        assessment.confidence_scores.negative,
                    ))
            print("\n")
        print("\n")
          
sentiment_analysis_with_opinion_mining_example(text_analytics_client)