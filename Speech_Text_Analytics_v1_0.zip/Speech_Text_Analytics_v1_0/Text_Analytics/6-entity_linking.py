# -*- coding: utf-8 -*-
"""
Created on Tue Mar  7 12:30:26 2023

@author: Dell
"""

import sys
sys.path.append('Text-Analytics')
from credential import client

"""
Entity linking
"""
client = client()
documents = ["""Microsoft was founded by Bill Gates and Paul Allen on April 4, 1975, 
to develop and sell BASIC interpreters for the Altair 8800. 
During his career at Microsoft, Gates held the positions of chairman,
chief executive officer, president and chief software architect, 
while also being the largest individual shareholder until May 2014."""]

response = client.recognize_linked_entities(documents = documents)

for doc in response:
    for entity in doc.entities:
        print('Entity Name: {0}; Entity Id: {1}'.format(entity.name, entity.data_source_entity_id))
        print('Source: {0}'.format(entity.data_source))
        print('Information Link: {0}'.format(entity.url))
        print('Matches:')
        for match in entity.matches:
            print('\tText: {0}'.format(match.text))
            print('\tConfidence Score: {0:.2f}'.format(match.confidence_score))
        print('-'*100)
        

def entity_linking_example(client):

    try:
        documents = ["""Microsoft was founded by Bill Gates and Paul Allen on April 4, 1975, 
        to develop and sell BASIC interpreters for the Altair 8800. 
        During his career at Microsoft, Gates held the positions of chairman,
        chief executive officer, president and chief software architect, 
        while also being the largest individual shareholder until May 2014."""]
        result = client.recognize_linked_entities(documents = documents)[0]

        print("Linked Entities:\n")
        for entity in result.entities:
            print("\tName: ", entity.name, "\tId: ", entity.data_source_entity_id, "\tUrl: ", entity.url,
            "\n\tData Source: ", entity.data_source)
            print("\tMatches:")
            for match in entity.matches:
                print("\t\tText:", match.text)
                print("\t\tConfidence Score: {0:.2f}".format(match.confidence_score))
                print("\t\tOffset: {}".format(match.offset))
                print("\t\tLength: {}".format(match.length))
            
    except Exception as err:
        print("Encountered exception. {}".format(err))
entity_linking_example(text_analytics_client)    